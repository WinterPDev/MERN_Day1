// GIVEN
// console.log(example);
// var example = "I'm the example!";
// AFTER HOISTING BY THE INTERPRETER
// var example;
// console.log(example); // logs undefined
// example = "I'm the example!";


console.log(hello);
var hello = 'world';
// returns undefined due to var declaration after the console log. 

